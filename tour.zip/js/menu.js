$(document).ready(function() {
    $('.menu_burger').click(function() {
        $('.menu_burger').toggleClass('open-menu');
        $('.burger_nav').toggleClass('open-menu')
    });
});